// import Grakn from 'grakn';
// async function test() {

//     const grakn = new Grakn('192.168.56.101:4567');
//     const session = grakn.session('keyspace');
//     const tx = await session.transaction(Grakn.txType.WRITE);
//     const resultIterator = await tx.query("match $x isa person; limit 10; get;"); // This will return an Iterator of ConceptMap Answer
//     const answer = await resultIterator.next(); // Take first ConceptMap Answer
//     const person = answer.map().get('x'); // Access map in Answer with answer.map() and take Concept associated to variable x from 'match $x isa person; get;'
//     tx.close();
// }
// test();