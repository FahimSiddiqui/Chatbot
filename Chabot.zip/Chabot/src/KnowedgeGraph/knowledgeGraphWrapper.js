export function getAction(data) {
    return undefined;
}