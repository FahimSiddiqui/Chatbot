export function getPreparedAction(action) {
    return undefined;
}
export function generateAction(params) {
    return undefined;
}
