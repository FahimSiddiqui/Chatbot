import { processRequest } from "../Controller/actionController";
import { inProcess } from "./inProcess";
var inProcesscontainer = undefined;
export function getInProcessData() {
    return inProcesscontainer;
}

export function setInProcessData(data) {
    inProcesscontainer = new inProcess(data);
}
export function resetInProcessData(data) {
    inProcesscontainer = undefined;
}

export function getNextInProcessParameter() {
    return inProcesscontainer.getNextParameter();
}

export function processInContextInput(input) {
    // getActiveParameter, set it and update.
    var activeParam = inProcesscontainer.getActiveParameter();
    var status = updateParameters(input, activeParam);
    if (status) {
        var param = getNextInProcessParameter();
        if (param) {
            param.status = "InProgress";
            return param.question;
        } else {
            // It means processing has been completed.
            var actionControllerResult = processRequest(inProcesscontainer);
            resetInProcessData();
            // if (actionControllerResult.needsMoreInfo) {

            // }
            return actionControllerResult;
        }
    } else {
        // will process this later.
    }
}

function validateInput(input, type) {
    return (checkType(input, type));
}

function checkType(input, type) {
    return (type === "numeric" && !isNaN(input.data)) || (input.type === "image" && type === "image"); // text by default true.
    // return true / false;
}

function updateParameters(input, parameter) {
    // Update inProcess parameter here:
    // Run validation on the type of response
    if (checkType(input, parameter.type)) {
        // if it matches, then update it for the current inprogress parameter
        parameter.value = input;
        parameter.status = "complete";
        return true;
    } else {
        return false;
    }
    // If validation fails twice, set status as incomplete and ask next question.
    // If users gives two wrong answer. Just clear the context and send the message to LUIS.

}