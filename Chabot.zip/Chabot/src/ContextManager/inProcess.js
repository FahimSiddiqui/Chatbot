export class inProcess {
    constructor(data) {
        this.obj = data;
    }
    getActiveParameter() {
        // for each parameter in InProcess, run a loop and check inProgress status.!
        for (var i = 0; i < this.obj.params.length; i++) {
            var entityParams = this.obj.params[i];
            for (var j = 0; j < entityParams.parameters.length; j++) {
                if (entityParams.parameters[j].status === "InProgress") {
                    return entityParams.parameters[j];
                }
            }
        }
        return this.obj.parameters[0];
    }

    getNextParameter() {
        for (var i = 0; i < this.obj.params.length; i++) {
            var entityParams = this.obj.params[i];
            for (var j = 0; j < entityParams.parameters.length; j++) {
                if (entityParams.parameters[j].status === "None") {
                    return entityParams.parameters[j];
                }
            }
        }
    }

};
