// import React from 'react';
// import ReactDOM from 'react-dom';
// import { Provider } from 'react-redux';
// import { createStore, applyMiddleware } from 'redux';
// import ReduxPromise from 'redux-promise';

// import App from './components/app';
// import reducers from './reducers';

// const createStoreWithMiddleware = applyMiddleware(ReduxPromise)(createStore);

// ReactDOM.render(
//   <Provider store={createStoreWithMiddleware(reducers)}>
//     <App />
//   </Provider>
//   , document.querySelector('.container'));

// --------------------------------------------------------//
// var lda = require('lda');

// // Example document.
// var text = 'I want to buy a business card. Do you have a design in mind. I have this design sample. It is a low resolution design. can you send me a proof. Shall I send you an email, kindly provide. Use the same email id.';

// // Extract sentences.
// var documents = text.match(/[^\.!\?]+[\.!\?]+/g);

// // Run LDA to get terms for 2 topics (5 terms each).
// var result = lda(documents, 5, 5);
// console.log(result);

// import * as all from "./UI/chatbotUIHandler";
import * as abc from "babel-polyfill";
//import * as graph from "./KnowedgeGraph/createKnowledgeGraph";

const Grakn = require("grakn");
async function test() {

    //const grakn = new Grakn('192.168.56.101:4567');
    // const session = grakn.session('keyspace');
    // const tx = await session.transaction(Grakn.txType.WRITE);
    // const resultIterator = await tx.query("match $x isa person; limit 10; get;"); // This will return an Iterator of ConceptMap Answer
    // const answer = await resultIterator.next(); // Take first ConceptMap Answer
    // const person = answer.map().get('x'); // Access map in Answer with answer.map() and take Concept associated to variable x from 'match $x isa person; get;'
    // tx.close();
}
test();