export function getDefaultParameters(input) {
    // Sending Dummy data;
    var data = {
        request: input,
        params: [{
            actionName: "hat",
            parameters: [{
                    entityName: "quantity",
                    caterogry: "hat",
                    type: "numeric",
                    // ["string", "numeric", "Image"]
                    status: "None",
                    // ["InProgress", "Completed", "Incomplete", "None"]
                    count: 0,
                    isMandatory: true, // / false,
                    value: undefined,
                    question: "How many quantities you want?",
                    counterQuestion: "I dont understand, How many quantities you want."
                },
                {
                    entityName: "design",
                    caterogry: "hat",
                    type: "image",
                    // ["string", "numeric", "Image"]
                    status: "None",
                    // ["InProgress", "Completed", "Incomplete", "None"]
                    count: 0,
                    isMandatory: true, // / false,
                    value: undefined,
                    question: "Do you have a design in mind",
                    counterQuestion: "I dont understand, Could you please provide an image(JPG/PNG)."
                }
            ],
            needsMoreInfo: true,
            response: "Need more information."
        }]
    };
    return data;
}
