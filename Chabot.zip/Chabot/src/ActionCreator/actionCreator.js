import {
    getDefaultParameters
} from "./taskConfiguration";
export function getNewAction(request) {
    return getDefaultParameters(request);
}

export function isCompleteRequest(action) {
    return false;
}
