import $ from "jquery";

export async function getIntentEntities(textData) {
    return new Promise(function (res, err) {
        $.ajax({
                url: "https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/2253a496-e763-4b64-98d0-67c8fb4bb178?subscription-key=d1959e9d53ba421596b558e66cfaefa6&staging=true&spellCheck=true&verbose=true&timezoneOffset=0&q=" + textData,
                type: "GET",
            })
            .done(function (data) {
                console.log("Inside getIntentEntities");
                console.log(data);
                res(data);
            })
            .fail(function () {
                alert("error");
                err(Error("Unable to connect"));
            });
    });
}
