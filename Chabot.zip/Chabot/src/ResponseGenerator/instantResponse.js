export function exposeInstantResponse (instantInput) {
    return "hi";

}