import { getDefaultParameters } from "./taskConfiguration";
export function completeAction(action) {
    var requestedParams = getDefaultParameters(action);
    // extract parameters - from the actions object.
    var actionParams = extractParametersFromAction(action);
    if (compareParameters(requestedParams, actionParams)) {
        return "Order has been placed";// executeAction(actionParams);
    }
    else {
        return requestedParams;
    }
    return data;
}

function compareParameters(requestParams, actionParams) {
    if (!actionParams) {
        return false;
    }
    for(var i=0; i< requestParams.parameters.length; i++) {
        var reqParam = requestParams.parameters[i];
        var correspondingActionParam = actionParams.parameters[i];
        if (correspondingActionParam.status === "None") {
            return false;
        }
    }
    return true;
}
