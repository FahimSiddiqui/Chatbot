import * as processor from "../Controller/controller"
import $ from "jquery";

$(document).ready(function () {
    $(".minimize").click(function () {
        $(".bot-body").hide();
        $(".main-window").animate({
            height: "25px"
        });
        $("#minimize-option").removeClass("minimize");
        $("#minimize-option").addClass("maximize");
    });
    $(".maximize").click(function () {
        Console.log("hhhhh");
        $(".bot-body").show();
        $(".main-window").animate({
            height: "400px"
        });
        $("#minimize-option").addClass("minimize");
        $("#minimize-option").removeClass("maximize");
    });
    $('#area').on("keypress", function (e) {
        if (e.keyCode == 13) {
            // alert("Enter pressed");
            readFromTextBox();
            return false;
        }
    });
    // $(".send-button").click(function () {
    //     start();
    // });
    $("#attachmentButtonReplacement").click(function () {
        $('#attachmentPicker').trigger('click');
    });
    $('#attachmentPicker').change(function (e) {
        start({
            data: e.target.files[0],
            type: "image"
        });
    });

});

function previewImageMessage(file) {
    var preview = document.createElement('img');
    var reader = new FileReader();

    reader.onloadend = function () {
        preview.src = reader.result;
    }

    if (file) {
        reader.readAsDataURL(file);
    } else {
        preview.src = "";
    }
    return preview;
}

function readFromTextBox() {
    var data = document.getElementById("area").value;
    addMessage({
        data,
        messageType: "user",
        type: "text"
    });
    document.getElementById("area").value = "";
    start({
        data,
        type: "text"
    });
}
async function start(data) {
    var response = await processor.getResponse(data);
    console.log("I have got the response");
    console.log(response);
    botMessageToUI(response);
    // processor.test();
}
export function botMessageToUI(message) {
    addMessage({
        data: message,
        messageType: "bot",
        type: "text"
    });
}
// function showData(data) {
//     for (var i = 0; i < 5; i++) {
//         var userMessage = "hi" + i;
//         var botMessage = "hello" + i;
//         addMessage({
//             data: userMessage,
//             messageType: "user",
//             type: "text"
//         });
//         addMessage({
//             data: botMessage,
//             messageType: "bot",
//             type: "text"
//         });
//     }
// }

export function addMessage(message) {
    var xyz = document.getElementById("mid-window");
    var messageBody = document.getElementById("mid-window-area");
    var messageBar = document.createElement("div");
    messageBar.className = message.messageType + "-message-bar";
    var messageObj = document.createElement("div");
    if (message.type === "image") {
        messageObj.className = message.messageType + "-message-image-holder";
        var img = previewImageMessage(message.data);
        img.className = message.messageType + "-message-image";
        messageObj.appendChild(img);
    } else {
        messageObj.className = message.messageType + "-message";
        messageObj.appendChild(document.createTextNode(message.data));
    }
    messageBar.appendChild(messageObj);
    messageBody.appendChild(messageBar);
    messageBody.scrollTop = messageBody.scrollHeight;
}
console.log("hi");
//showData();