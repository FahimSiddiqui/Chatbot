import { getNewAction, isCompleteRequest } from "../ActionCreator/actionCreator";
export function processRequest(input) {
    // if It contains parameter, then processed request else new request.
    if (input.params) {
        // old/processed request
    } else {
        var newRequest = getNewAction(input);
        if (isCompleteRequest(newRequest)) {
            // ask Agent to execute it.
        } else {
            // return the params and ask for more details.
            newRequest.needsMoreInfo = true;
            return newRequest;
        }
    }
}