import {
    getIntentEntities
} from "../TextProcessor/LuisHandler";
import {
    exposeInstantResponse
} from "../ResponseGenerator/instantResponse";
import {
    getInProcessData,
    setInProcessData,
    getNextInProcessParameter,
    processInContextInput
} from "../ContextManager/contextHandler";
import {
    processRequest
} from "./actionController";
const instantProcessedEntities = ["greeting"];
export async function getResponse(inputData) {
    const inProcessObject = getInProcessData();
    if (inProcessObject) {
        // Do nothing.
        return processInContextInput(inputData);
    } else {
        // const intentEntites =  JSON.parse(fs.readFileSync("C:\\Users\\e90037404\\Desktop\\greeting.json",'utf8')); // await getIntentEntities(inputData.data);
        var p = new Promise(function (res, error) {
            fetch("..\\test\\BuyHat.json")
                .then(response => response.json())
                .then(intentEntites => {
                    console.log(intentEntites);
                    const parsedIntentEntites = parseIntentEntities(intentEntites); // topScoringIntent, entities. Intent.
                    if (instantProcessedEntities.indexOf(parsedIntentEntites.topScoringIntent) !== -1) {
                        res(exposeInstantResponse(parsedIntentEntites));
                    } else {
                        // New request, need to process it.
                        var actionControllerResult = processRequest(parsedIntentEntites);
                        if (actionControllerResult.needsMoreInfo) {
                            setInProcessData(actionControllerResult);
                            var param = getNextInProcessParameter();
                            param.status = "InProgress";
                            res(param.question);
                        }
                    }
                });
        });
        return p.then(result => {
            return result;
        });
    }
}

// async function readTextFile(file) {
//     var rawFile = new XMLHttpRequest();
//     rawFile.open("GET", file, false);
//     rawFile.onreadystatechange = await

//     function () {
//         if (rawFile.readyState === 4) {
//             if (rawFile.status === 200 || rawFile.status == 0) {
//                 var allText = rawFile.responseText;
//                 rawFile.send(allText);
//             }
//         }
//     }
//     rawFile.send("hehe");
// }
export function parseIntentEntities(intentEntites) {
    return {
        topScoringIntent: intentEntites.topScoringIntent ? intentEntites.topScoringIntent.intent : intentEntites.intents[0].intent,
        otherIntents: intentEntites.intents,
        entities: extractEntities(intentEntites.entities)
    };
}

function extractEntities(entities) {
    const entityList = [];
    for (let i = 0; i < entities.length; i++) {
        entityList.push(entities[i].entity);
    }
    return entityList;
}