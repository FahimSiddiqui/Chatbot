// import {
//     getIntentEntities
// } from "../TextProcessor/LuisHandler";
// import {
//     completeAction
// } from "../Agents/preCheckAgent";
// import {
//     getAction
// } from "../KnowedgeGraph/knowledgeGraphWrapper";
// import {
//     getPreparedAction,
//     generateAction
// } from "../KnowedgeGraph/prepareAction"
// var inProcess;
// var knowsActions = [];

// export function setInProcess(obj) {
//     inProcess = obj;
// }

// export function resetInProcess() {
//     inProcess = undefined;
// }
// export async function getResponse(data) {
//     if (inProcess) {
//         // get the current parameter.
//         var parameter = getActiveParameter(inProcess);
//         // update the parameter.
//         try {
//             updateParameters(data, parameter);
//         } catch (e) {
//             // Ask counterQuestion for the current parameter.
//             return parameter.counterQuestion;
//         }
//         // check all the parameters in textData has been filled.
//         var param = getNextParameter(inProcess);
//         // if available, then pick one, send question to to UI, set the status as InProgress.
//         if (param) {
//             param.status = "InProgress";
//             return param.question;
//         } else {
//             var action = generateAction(inProcess);
//             resetInProcess();
//             return processAction(action);
//             // return "I have placed the order. Thank you.";
//             // pass it for actionCompletion.
//         }
//     } else {
//         var nluProcessed; // await getIntentEntities(textData);
//         // Parse LUI response
//         var parseData = parseIntentEntities(nluProcessed);
//         // Understand parsedData from Knowledge Graph and return action for agent to perform it.
//         var action = await getAction(parseData);
//         // Check if known action, if not then prepare action execution.
//         if (!checkKnownAction(action)) {
//             action = getPreparedAction(action);
//         }
//         // Pass it to agent, based on the type it will perform action.
//         return processAction(action);
//     }
// }
// async function processAction(action) {
//     var agentResponse = await completeAction(action);
//     // Assumed, response has been parsed from ResponseGenerator.
//     // Does it need to be set inProcess object. If yes set, if no return.
//     if (agentResponse.needsMoreInfo) {
//         setInProcess(agentResponse);
//         console.log(inProcess);
//         var param = getNextParameter(inProcess);
//         param.status = "InProgress";
//         return param.question;
//     } else {
//         return agentResponse.response;
//     }
// }

// function checkKnownAction(action) {
//     // check in the list of defined actions.
//     // return boolean.
//     return true;
// }

// function parseIntentEntities(data) {
//     return data;
// }

// function updateParameters(input, parameter) {
//     // Update inProcess parameter here:
//     // Run validation on the type of response
//     if (checkType(input, parameter.type)) {
//         // if it matches, then update it for the current inprogress parameter
//         parameter.value = input;
//         parameter.status = "complete";
//     } else {
//         throw Error("validation failed");
//     }
//     // If validation fails twice, set status as incomplete and ask next question.
//     // If users gives two wrong answer. Just clear the context and send the message to LUIS.

// }

// function checkType(input, type) {
//     return (type==="numeric" && !isNaN(input.data)) || (input.type === "image" && type === "image"); // text by default true.
//     // return true / false;
// }

// function getActiveParameter(inProcess) {
//     // for each parameter in InProcess, run a loop and check inProgress status.!
//     for (var i = 0; i < inProcess.parameters.length; i++) {
//         if (inProcess.parameters[i].status === "InProgress") {
//             return inProcess.parameters[i];
//         }
//     }
//     return inProcess.parameters[0];

// }

// function getNextParameter(inProcess) {
//     for (var i = 0; i < inProcess.parameters.length; i++) {
//         if (inProcess.parameters[i].status === "None") {
//             return inProcess.parameters[i];
//         }
//     }
// }
// // export function test() {
// //     var lda = require('lda');

// //     // Example document.
// //     var text = 'Cats are small. Dogs are big. Cats like to chase mice. Dogs like to eat bones.';

// //     // Extract sentences.
// //     var documents = text.match(/[^\.!\?]+[\.!\?]+/g);

// //     // Run LDA to get terms for 2 topics (5 terms each).
// //     var result = lda(documents, 2, 5);
// //     console.log(result);
// // }